package com.bitspilani.poorima;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CreateRemainderFragment extends Fragment implements View.OnClickListener{

    private static final String TAG = CreateRemainderFragment.class.getCanonicalName();
    EditText mTitleText;
    EditText mDescriptionText;
    Spinner mSpinner;
    DatePicker pickerDate;
    TimePicker pickerTime;
    TextView time;
    TextView date;
    CheckBox checkBoxAlarm,checkboxnotify;
    private Button submit;
    private Remainder remainder;

    public static CreateRemainderFragment getInstance(){
        CreateRemainderFragment createRemainder = new CreateRemainderFragment();
        return createRemainder;
    }
    public static CreateRemainderFragment getInstance(Remainder remainder) {
        CreateRemainderFragment createRemainder = new CreateRemainderFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("remainders", remainder);
        createRemainder.setArguments(bundle);
        return createRemainder;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        mCalendar = Calendar.getInstance();
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_remainder, container, false);
        init(view);
        return view;
    }

    private void init(View view){
        mTitleText = (EditText) view.findViewById(R.id.txttitle);
        mDescriptionText = (EditText) view.findViewById(R.id.description);
        mSpinner = (Spinner) view.findViewById(R.id.spinnerNoteType);
        pickerDate = (DatePicker) view.findViewById(R.id.datePicker);
        pickerTime = (TimePicker) view.findViewById(R.id.timePicker);
        time = (TextView) view.findViewById(R.id.txtTime);
        date = (TextView) view.findViewById(R.id.txtDate);
        checkBoxAlarm = (CheckBox) view.findViewById(R.id.checkBox);
        checkboxnotify = (CheckBox) view.findViewById(R.id.checkBox2);
        submit = (Button) view.findViewById(R.id.submit);
        submit.setOnClickListener(this);


        pickerDate.setVisibility(View.INVISIBLE);
        pickerTime.setVisibility(View.INVISIBLE);
        time.setVisibility(View.INVISIBLE);
        date.setVisibility(View.INVISIBLE);

        Bundle bundle = getActivity().getIntent().getExtras();
        if(bundle != null){
            remainder = (Remainder) bundle.getSerializable("remainders");
            Log.d(TAG, "My notes is "+remainder);
        }


        ArrayAdapter adapter = ArrayAdapter.createFromResource(
                getActivity(), R.array.note_type, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinner.setAdapter(adapter);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(
                    AdapterView parent, View view, int position, long id) {
                if(id == 2){
                    showToast(getString(R.string.added_alert));
                    checkBoxAlarm.setEnabled(true);
                }
                else {
                    checkBoxAlarm.setEnabled(false);
                    checkBoxAlarm.setChecked(false);
                }
                if(id == 3){
                    showToast(getString(R.string.notify));
                    checkboxnotify.setEnabled(true);
                }
                else {
                    checkboxnotify.setEnabled(false);
                    checkboxnotify.setChecked(false);
                }
            }

            public void onNothingSelected(AdapterView parent) {
            }
        });

        checkBoxAlarm.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true){
                    pickerDate.setVisibility(View.VISIBLE);
                    pickerTime.setVisibility(View.VISIBLE);
                    time.setVisibility(View.VISIBLE);
                    date.setVisibility(View.VISIBLE);
                }
                else{
                    pickerDate.setVisibility(View.INVISIBLE);
                    pickerTime.setVisibility(View.INVISIBLE);
                    time.setVisibility(View.INVISIBLE);
                    date.setVisibility(View.INVISIBLE);
                }
            }
        });
        checkboxnotify.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true){
                    pickerDate.setVisibility(View.VISIBLE);
                    pickerTime.setVisibility(View.VISIBLE);
                    time.setVisibility(View.VISIBLE);
                    date.setVisibility(View.VISIBLE);
                }
                else{
                    pickerDate.setVisibility(View.INVISIBLE);
                    pickerTime.setVisibility(View.INVISIBLE);
                    time.setVisibility(View.INVISIBLE);
                    date.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    void showToast(CharSequence msg) {
        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        if(remainder!= null){
            updateTask(remainder);
        }else
            saveNote();
    }
    String dateString;
    String timeString;


    private void saveNote(){
        final String sTask = mTitleText.getText().toString().trim();
        final String sDesc = mDescriptionText.getText().toString().trim();

        if (sTask.isEmpty()) {
            mTitleText.setError("Title required");
            mTitleText.requestFocus();
            return;
        }

        if (sDesc.isEmpty()) {
            mDescriptionText.setError("Desc required");
            mDescriptionText.requestFocus();
            return;
        }

        if(checkBoxAlarm.isChecked()){
            Calendar calender = Calendar.getInstance();
            calender.clear();
            calender.set(Calendar.MONTH, pickerDate.getMonth());
            calender.set(Calendar.DAY_OF_MONTH, pickerDate.getDayOfMonth());
            calender.set(Calendar.YEAR, pickerDate.getYear());
            calender.set(Calendar.HOUR, pickerTime.getCurrentHour());
            calender.set(Calendar.MINUTE, pickerTime.getCurrentMinute());
            calender.set(Calendar.SECOND, 00);


            SimpleDateFormat formatter = new SimpleDateFormat(getString(R.string.hour_minutes));
             timeString = formatter.format(new Date(calender.getTimeInMillis()));
            SimpleDateFormat dateformatter = new SimpleDateFormat(getString(R.string.dateformate));
             dateString = dateformatter.format(new Date(calender.getTimeInMillis()));

            AlarmManager alarmMgr = (AlarmManager)getActivity().getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getActivity(), AlarmReceiver.class);

            String alertTitle = mTitleText.getText().toString();
            intent.putExtra(getString(R.string.alert_title), alertTitle);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(), 0, intent, 0);

            alarmMgr.set(AlarmManager.RTC_WAKEUP, calender.getTimeInMillis(), pendingIntent);
        } else if(checkboxnotify.isChecked()){
            Calendar calender = Calendar.getInstance();
            calender.clear();
            calender.set(Calendar.MONTH, pickerDate.getMonth());
            calender.set(Calendar.DAY_OF_MONTH, pickerDate.getDayOfMonth());
            calender.set(Calendar.YEAR, pickerDate.getYear());
            calender.set(Calendar.HOUR, pickerTime.getCurrentHour());
            calender.set(Calendar.MINUTE, pickerTime.getCurrentMinute());
            calender.set(Calendar.SECOND, 00);

            SimpleDateFormat formatter = new SimpleDateFormat(getString(R.string.hour_minutes));
            timeString = formatter.format(new Date(calender.getTimeInMillis()));
            SimpleDateFormat dateformatter = new SimpleDateFormat(getString(R.string.dateformate));
            dateString = dateformatter.format(new Date(calender.getTimeInMillis()));

            AlarmManager alarmMgr = (AlarmManager)getActivity().getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(getActivity(), NotificationManager2.class);

            String alertTitle = mTitleText.getText().toString();
            String alertContent=mDescriptionText.getText().toString();
            intent.putExtra(getString(R.string.alert_title), alertTitle);
            intent.putExtra(getString(R.string.alert_content), alertContent);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(getActivity(), 0, intent, 0);

            alarmMgr.set(AlarmManager.RTC_WAKEUP, calender.getTimeInMillis(), pendingIntent);

        }

        class SaveNote extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                Remainder notes = new Remainder();
                notes.setFirstName(sTask);
                notes.setDesc(sDesc);
                notes.createDate = dateString;
                notes.dob = timeString;


                DatabaseClient.getInstance(getActivity()).getAppDatabase()
                        .remainderDao()
                        .insert(notes);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);

                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_LONG).show();
                Intent intent = new Intent();
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        }

        SaveNote st = new SaveNote();
        st.execute();
    }
    private void updateTask(final Remainder task) {
        final String sTask = mTitleText.getText().toString().trim();
        final String sDesc = mDescriptionText.getText().toString().trim();

        if (sTask.isEmpty()) {
            mTitleText.setError("Title required");
            mTitleText.requestFocus();
            return;
        }

        if (sDesc.isEmpty()) {
            mDescriptionText.setError("Desc required");
            mDescriptionText.requestFocus();
            return;
        }

        class UpdateTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                task.setFirstName(sTask);
                task.setDesc(sDesc);

                DatabaseClient.getInstance(getActivity()).getAppDatabase()
                        .remainderDao()
                        .update(task);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(getActivity(), "Updated", Toast.LENGTH_LONG).show();
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
//                finish();
//                startActivity(new Intent(UpdateTaskActivity.this, MainActivity.class));
            }
        }

        UpdateTask ut = new UpdateTask();
        ut.execute();
    }


}
