package com.bitspilani.poorima;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class NotesListFragment extends Fragment implements  NoteAdapter.OnNoteItemClick{

    private static final String TAG = NotesListFragment.class.getCanonicalName();
    private List<Notes> taskList;
    private RecyclerView mRecyclerView;
    private TextView mEmptyView;
    private NoteAdapter adapter;

    public static NotesListFragment getInstance(){
        NotesListFragment notesList = new NotesListFragment();
        return notesList;
    }

    @Override
    public void onNoteClick(final int pos) {
        new AlertDialog.Builder(getActivity())
                .setTitle("Select Options")
                .setItems(new String[]{"Delete", "Update"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i){
                            case 0:
                                deleteTask(taskList.get(pos));

                                break;
                            case 1:
                                Intent intent = new Intent(getActivity(), AddNoteActivity.class);
                                intent.putExtra("notes", taskList.get(pos));
                                startActivityForResult(intent, 100);


                                break;
                        }
                    }
                }).show();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notes_list, container, false);

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerview_tasks);
        mEmptyView = (TextView) view.findViewById(R.id.emptyView);
        mEmptyView.setVisibility(View.VISIBLE);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new NoteAdapter(getActivity(), this);
        mRecyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getTasks();
    }

    private void getTasks() {
        class GetTasks extends AsyncTask<Void, Void, List<Notes>> {

            @Override
            protected List<Notes> doInBackground(Void... voids) {
                taskList = DatabaseClient
                        .getInstance(getActivity())
                        .getAppDatabase()
                        .notesDao()
                        .getAll();
                return taskList;
            }

            @Override
            protected void onPostExecute(List<Notes> tasks) {
                super.onPostExecute(tasks);
                if(tasks != null && tasks.size() > 0) {
                    mEmptyView.setVisibility(View.GONE);

                    mRecyclerView.setVisibility(View.VISIBLE);
                    adapter.setList(tasks);
                    adapter.notifyDataSetChanged();
                }else{
                    mRecyclerView.setVisibility(View.GONE);
                    mEmptyView.setVisibility(View.VISIBLE);
                }
            }
        }

        GetTasks gt = new GetTasks();
        gt.execute();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 01 && resultCode == Activity.RESULT_OK){
            getTasks();
        }else if(requestCode == 100 && resultCode == Activity.RESULT_OK){
            getTasks();
        }
    }

    private void deleteTask(final Notes task) {
        class DeleteTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                DatabaseClient.getInstance(getActivity()).getAppDatabase()
                        .notesDao()
                        .delete(task);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(getActivity(), "Deleted", Toast.LENGTH_LONG).show();
//                finish();
                getTasks();
            }
        }

        DeleteTask dt = new DeleteTask();
        dt.execute();

    }
}
