package com.bitspilani.poorima;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface RemainderDao {

    @Query("SELECT * FROM remainder")
    List<Remainder> getAll();

    @Insert
    void insert(Remainder remainder);

    @Delete
    void delete(Remainder... remainders);

    @Update
    void update(Remainder remainder);
}
