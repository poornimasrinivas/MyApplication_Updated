package com.bitspilani.poorima;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ScheduleMessageList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_message_list);
    }
}
