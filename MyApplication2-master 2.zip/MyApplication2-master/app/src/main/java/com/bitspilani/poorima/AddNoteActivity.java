package com.bitspilani.poorima;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class AddNoteActivity extends AppCompatActivity {

    private Notes notes;
    private String TAG = AddNoteActivity.class.getCanonicalName();
    private CreateNoteFragment createNoteFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        Bundle bundle = getIntent().getExtras();
        if(bundle != null){
            notes = (Notes) bundle.getSerializable("notes");
            Log.d(TAG, "My notes is "+notes);
        }

        if(notes != null){
            createNoteFragment = CreateNoteFragment.getInstance();
        }else
         createNoteFragment = CreateNoteFragment.getInstance();
        FragmentTransaction fTransaction = getSupportFragmentManager().beginTransaction();
        fTransaction.add(R.id.add_container, createNoteFragment, "Create Notes");
        fTransaction.commit();
    }
}
