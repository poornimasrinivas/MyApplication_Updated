package com.bitspilani.poorima;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;

@Database(entities = {Notes.class, Remainder.class}, version =  1)
@TypeConverters({DateConverter.class})
public abstract  class AppDatabase extends RoomDatabase {

    public abstract NotesDao notesDao();

    public abstract RemainderDao remainderDao();
}
