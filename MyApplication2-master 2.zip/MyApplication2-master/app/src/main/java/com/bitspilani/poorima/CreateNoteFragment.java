package com.bitspilani.poorima;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateNoteFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = CreateNoteFragment.class.getCanonicalName();
    /*private EditText mName;
    private EditText mDesc;
    private EditText mCellNo;
    private EditText mDate;
    private EditText mTime;
    private Calendar mCalendar;
*/

    private EditText mTitle;
    private EditText mContentArea;
    private Button mSave;
    private Notes notes;

    public static CreateNoteFragment getInstance() {
        CreateNoteFragment createNote = new CreateNoteFragment();
        return createNote;
    }

    public static CreateNoteFragment getInstance(Notes notes) {
        CreateNoteFragment createNote = new CreateNoteFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("notes", notes);
        createNote.setArguments(bundle);
        return createNote;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        mCalendar = Calendar.getInstance();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_note, container, false);
        init(view);
        return view;
    }


    private void init(View view) {
        mTitle = (EditText) view.findViewById(R.id.et_title);
        mContentArea = (EditText) view.findViewById(R.id.et_content);
        mSave = (Button) view.findViewById(R.id.but_save);
        mSave.setOnClickListener(this);

        Bundle bundle = getActivity().getIntent().getExtras();
        if(bundle != null){
            notes = (Notes) bundle.getSerializable("notes");
            Log.d(TAG, "My notes is "+notes);
        }

        if(notes != null){
            mTitle.setText(notes.getTitle());
            mContentArea.setText(notes.getContent());
        }
       /* mName = (EditText) view.findViewById(R.id.editTextName);
        mDesc = (EditText) view.findViewById(R.id.editTextDec);
        mCellNo = (EditText) view.findViewById(R.id.editTextCell);
        mTime = (EditText) view.findViewById(R.id.editTextTime);
        mTime.setOnClickListener(this);
        mDate = (EditText) view.findViewById(R.id.editTextDate);
        mDate.setOnClickListener(this);*/
    }

    @Override
    public void onClick(View v) {
        if(notes != null){
            updateTask(notes);
        }else
        saveNote();
         /*switch (v.getId()) {
           case R.id.editTextDate:
                new DatePickerDialog(getActivity(), date, mCalendar
                        .get(Calendar.YEAR), mCalendar.get(Calendar.MONTH),
                        mCalendar.get(Calendar.DAY_OF_MONTH)).show();
                break;
            case R.id.editTextTime:
                new TimePickerDialog(getActivity(), time, mCalendar.get(Calendar.HOUR_OF_DAY),
                        mCalendar.get(Calendar.MINUTE), false).show();
                break;
        }*/
    }
/*
    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub
            mCalendar.set(Calendar.YEAR, year);
            mCalendar.set(Calendar.MONTH, monthOfYear);
            mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }

    };

    TimePickerDialog.OnTimeSetListener time = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            mCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            mCalendar.set(Calendar.MINUTE, minute);
            updateHour();
        }
    };

    private void updateHour() {

    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

//        edittext.setText(sdf.format(mCalendar.getTime()));
    }*/

    private void saveNote(){
        final String sTask = mTitle.getText().toString().trim();
        final String sDesc = mContentArea.getText().toString().trim();

        if (sTask.isEmpty()) {
            mTitle.setError("Title required");
            mTitle.requestFocus();
            return;
        }

        if (sDesc.isEmpty()) {
            mContentArea.setError("Desc required");
            mContentArea.requestFocus();
            return;
        }

        class SaveNote extends AsyncTask<Void, Void, Void>{

            @Override
            protected Void doInBackground(Void... voids) {
                Notes notes = new Notes();
                notes.setTitle(sTask);
                notes.setContent(sDesc);

                DatabaseClient.getInstance(getActivity()).getAppDatabase()
                        .notesDao()
                        .insert(notes);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);

                Toast.makeText(getActivity(), "Saved", Toast.LENGTH_LONG).show();
                Intent  intent = new Intent();
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        }

        SaveNote st = new SaveNote();
        st.execute();
    }

    private void updateTask(final Notes task) {
        final String sTask = mTitle.getText().toString().trim();
        final String sDesc = mContentArea.getText().toString().trim();

        if (sTask.isEmpty()) {
            mTitle.setError("Title required");
            mTitle.requestFocus();
            return;
        }

        if (sDesc.isEmpty()) {
            mContentArea.setError("Desc required");
            mContentArea.requestFocus();
            return;
        }

        class UpdateTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                task.setTitle(sTask);
                task.setContent(sDesc);

                DatabaseClient.getInstance(getActivity()).getAppDatabase()
                        .notesDao()
                        .update(task);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                Toast.makeText(getActivity(), "Updated", Toast.LENGTH_LONG).show();
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
//                finish();
//                startActivity(new Intent(UpdateTaskActivity.this, MainActivity.class));
            }
        }

        UpdateTask ut = new UpdateTask();
        ut.execute();
    }



    //https://www.simplifiedcoding.net/android-room-database-example/
}
