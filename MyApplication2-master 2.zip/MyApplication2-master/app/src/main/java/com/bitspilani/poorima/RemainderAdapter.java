package com.bitspilani.poorima;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class RemainderAdapter extends RecyclerView.Adapter<RemainderAdapter.BeanHolder> {

    private List<Remainder> list;
    private Context context;
    private LayoutInflater layoutInflater1;
    private onRemainderItemClick onRemainderItemClick;

    public RemainderAdapter(Context context, onRemainderItemClick onRemainderItemClick) {
        layoutInflater1 = LayoutInflater.from(context);

        this.context = context;
        this.onRemainderItemClick = onRemainderItemClick;
    }

    public void setList(List<Remainder> list){
        this.list = list;

    }


    @Override
    public BeanHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater1.inflate(R.layout.adapter_recycler_view1,parent,false);
        return new BeanHolder(view);
    }

    @Override
    public void onBindViewHolder(BeanHolder holder, int position) {
        holder.textViewTitle.setText(list.get(position).getFirstName());
        holder.textViewContent.setText(list.get(position).getDesc());
    }

    @Override
    public int getItemCount() {
        Log.d("My Items are", "My get item count is "+ list.size());
        return list.size();
    }

    public class BeanHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView textViewContent;
        TextView textViewTitle;
        public BeanHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            textViewContent = itemView.findViewById(R.id.item_text);
            textViewTitle = itemView.findViewById(R.id.tv_title);
        }

        @Override
        public void onClick(View view) {
            onRemainderItemClick.onRemainderItemClick(getAdapterPosition());
        }
    }

    public interface onRemainderItemClick{
        void onRemainderItemClick(int pos);
    }
}
