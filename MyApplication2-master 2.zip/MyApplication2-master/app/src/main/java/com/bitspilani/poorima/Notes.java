package com.bitspilani.poorima;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.io.Serializable;
import java.util.Date;

@Entity
public class Notes implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int note_id;

    @ColumnInfo(name="title")
    private String title;

    @ColumnInfo(name="note_content")
    private String content;

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setNote_id(int note_id) {
        this.note_id = note_id;
    }

    public int getNote_id() {
        return note_id;
    }

    /* @ColumnInfo(name="name")
    private String name;

    @ColumnInfo(name = "note_desc")
    private String desc;

    @ColumnInfo(name = "birth_date")
    private Date date;

    @ColumnInfo(name = "timeInMillis")
    private long timeInMillis;

    @ColumnInfo(name = "phoneNo")
    private String cellNo;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCellNo(String cellNo) {
        this.cellNo = cellNo;
    }

    public String getCellNo() {
        return cellNo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDate() {
        return date;
    }

    public void setTimeInMillis(long timeInMillis) {
        this.timeInMillis = timeInMillis;
    }

    public long getTimeInMillis() {
        return timeInMillis;
    }*/
}
